﻿using UnityEngine;
using System.Collections;

public class ButtonScriptLeaveGame : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void SceneChange(int changeToScene)
	{
		// SceneManager.LoadScene(ChanegTheScene);
		Application.LoadLevel(changeToScene);
	}
}
