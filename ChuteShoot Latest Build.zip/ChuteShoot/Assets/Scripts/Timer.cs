﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Data.SqlClient;

public class Timer : MonoBehaviour
{
    public Text timerText;
    private float startTime;
    private bool finished = false;
	public int changeToScene;
    public float finishedScore = 0;
    public string connectionString =
        "Server=tcp:anthonydb.database.windows.net,1433;" +
        "Initial Catalog=AnthonyDB;" +
        "Persist Security Info=False;" +
        "User ID=Anthony;" +
        "Password=SuperBoy1" +
        "MultipleActiveResultSets=False;" +
        "Encrypt=False;" +
        //"TrustServerCertificate;Connection Timeout=30;";
        "Connection Timeout=30;";

    // Use this for initialization
    void Start () {
        startTime = Time.time;
    }
	
	// Update is called once per frame
	void Update () {
        if (finished == true)
        {
            return;
        }

        float t = Time.time - startTime;
        string seconds = (t % 60).ToString("f2");
        finishedScore = t;

        var requestQuery = "select MAX from dbo.Highscores.Score";

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            var command =
            new SqlCommand("INSERT INTO dbo.Highscores(Score) VALUES (@score);", connection);
            command.Parameters.AddWithValue("@textValue", finishedScore);
            command.ExecuteNonQuery();
            connection.Close();
        }

        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            var command =
            new SqlCommand("SELECT MAX(Scores) from dbo.Highscores;", connection);
            command.ExecuteNonQuery();
            connection.Close();
        }

        timerText.text = seconds;
		if(changeToScene == 2)
		{
		    finished = true;	
		}
	}

    public void Finish()
    {
        timerText.color = Color.yellow;
    }
}
